# LineaLinkR · BUILD NOTES

This file documents the build matrix, Windows toolchain choices, and the
Windows toolchain investigation for the extendr-based R package build.
Read it before opening
any environment-related issue.

---

## 1.  What gets built

`R CMD INSTALL .` triggers the following chain:

1. R reads `src/Makevars` (Linux/macOS) or `src/Makevars.win` (Windows).
2. The Makevars target `$(STATLIB)` invokes
   `cargo build --release --features extendr` against the project-root
   `Cargo.toml`, producing `target/<target>/release/liblinealinkr.a`
   (Unix-style staticlib name on both Linux/macOS and Windows-GNU).
3. R then compiles `src/entrypoint.c` to `entrypoint.o`.
4. R links `entrypoint.o + liblinealinkr.a + system libs` into
   `src/LineaLinkR.so` (Linux), `.dylib` (macOS), or `.dll` (Windows).
5. `R_init_LineaLinkR` (forward in `entrypoint.c`) calls
   `R_init_LineaLinkR_extendr`, which is the registrator that
   `extendr_module! { mod LineaLinkR; ... }` synthesises in
   `src/extendr_bindings.rs`.
6. `useDynLib(LineaLinkR, .registration = TRUE)` in `NAMESPACE` makes
   each `wrap__rs_*` symbol available as a native R object, which
   `R/wrap__LineaLinkR.R` calls via `.Call(wrap__rs_*, ...)`.

---

## 2.  Required tools

- **R** ≥ 4.2.
- **Rust** ≥ 1.65 (any stable cargo can drive the build).
- **GNU make** (Rtools provides this on Windows).
- On Windows: the **GNU rustc target** `x86_64-pc-windows-gnu`,
  installed via `rustup target add x86_64-pc-windows-gnu`.  This is
  required because R for Windows is itself built with the MinGW-w64
  toolchain shipped in Rtools, and ABI compatibility with the Rust
  staticlib requires the same toolchain family.

---

## 3.  Windows toolchain options (sorted by recommendation)

LineaLinkR's Windows build resolves to a `mingw-w64`-flavoured
`x86_64-pc-windows-gnu` cargo target.  The exact gcc that backs that
target matters because Rust's std links against `libgcc_eh.a` by
default, and not all `mingw-w64` distributions ship one.

### Option A · MSYS2 mingw-w64  (**VERIFIED 2026-05-11, recommended**)

Cleanest, most reproducible.  Installs a complete GCC + `libgcc.a` +
`libgcc_eh.a` that matches Rust's GNU sysroot expectations out of the
box.

```pwsh
# Install MSYS2 from https://www.msys2.org, then in the MSYS2 MINGW64 shell:
pacman -Syu                                      # first pass may request close + reopen
pacman -Syu                                      # second pass after reopen
pacman -S --needed mingw-w64-x86_64-toolchain
```

Prepend `C:\msys64\mingw64\bin` to `PATH` so that `where.exe gcc`
resolves to `C:\msys64\mingw64\bin\gcc.exe` — it MUST come before any
other gcc on the system (e.g. TDM under `D:\TDM\bin`).  If system-level
`PATH` cannot be edited (no admin rights, registry access denied), set
it per-command inside PowerShell:

```pwsh
$env:PATH = 'C:\msys64\mingw64\bin;' + $env:PATH
```

Verified on this machine (2026-05-11):

- `gcc --version` → `x86_64-w64-mingw32 16.1.0 (Rev2, Built by MSYS2 project)`.
- `gcc -print-libgcc-file-name` →
  `C:/msys64/mingw64/lib/gcc/x86_64-w64-mingw32/16.1.0/libgcc.a` (3 030 662 bytes).
- Real `libgcc_eh.a` in the same directory: 11 726 bytes (**not empty**).
- `cargo +stable-x86_64-pc-windows-gnu test --lib` → 9/9 PASS.
- `cargo build --release --features extendr` → 1 m 05 s clean build.
- `R CMD INSTALL .` → `* DONE (LineaLinkR)`.
- `library(LineaLinkR); TrajectoryDE(...); ComputePseudotimeFuzzy(...)`
  end-to-end smoke all return sensible values.

**Do NOT enable the `libgcc_eh.a` mock under this toolchain.**  The
mock in `src/Makevars.win` is therefore gated behind the env-var
`LINEALINKR_NEED_LIBGCC_EH_MOCK` (empty / unset by default); see §4 for
the full story of why a zero-byte stub silently shadowing a real
`libgcc_eh.a` breaks the link.

### Option B · winlibs mingw-w64

Stand-alone zip distribution.  Download the latest UCRT or MSVCRT
build from <https://winlibs.com>, unpack to e.g. `C:\winlibs`, add
`C:\winlibs\mingw64\bin` to `PATH`.  Same behaviour as MSYS2.

### Option C · Rtools 4.x toolchain

If R was installed via Rtools, the `mingw-w64` toolchain shipped with
Rtools is already on `PATH` during `R CMD INSTALL`. This is the simplest
configuration when Rtools is installed, and no mock setting is required.

### Option D · TDM-GCC  (legacy / not recommended; opt-in mock required)

TDM-GCC 10.3 — historically the system gcc on this development
machine — ships neither a usable `libgcc_eh.a` nor merged unwinding in
`libgcc.a`, so the default Rust GNU linker script fails with
`cannot find -lgcc_eh`. TDM builds require:

```pwsh
$env:LINEALINKR_NEED_LIBGCC_EH_MOCK = '1'
```

before running `R CMD INSTALL .`.  This tells `src/Makevars.win` to
synthesise a zero-byte `libgcc_eh.a` stub under
`target/libgcc_mock/`, prepend its directory to `LIBRARY_PATH`, and
run cargo with that env.  The stub merely satisfies the linker's
`-lgcc_eh` symbol lookup; real unwinding symbols come from
`libgcc_s_seh-1.dll` at load time.

**Why the mock is opt-in rather than always-on**: if applied on top of
a toolchain that DOES have a real `libgcc_eh.a` (MSYS2 / winlibs /
Rtools 4.5+), the empty stub appears first on `LIBRARY_PATH` and
silently shadows the real one — producing
`undefined reference to '_Unwind_Resume'` (dozens of times),
`_Unwind_GetTextRelBase`, `_GCC_specific_handler`, etc. at the final
link step.  This regression was observed during P4 and is the reason
the mock MUST NOT be default.

Even with the opt-in stub, TDM additionally produced
`ApplicationFailedException` when Windows executed Rust build-script
binaries during P4 — a PE-segment incompatibility between TDM's MinGW
and Rust's GNU sysroot, not a missing-DLL problem.  **Switch to
Option A or B if at all possible.**

### Option E · MSVC (`x86_64-pc-windows-msvc`)

Also viable (`rustup target add x86_64-pc-windows-msvc`) but requires
a full Visual Studio Build Tools install with the **"Desktop
development with C++"** workload (i.e. an actual `link.exe` and
`cl.exe`).  An IDE-only VS install does NOT include this.  The
LineaLinkR Makevars is **not** wired for the MSVC target. Supporting it
requires replacing `-pc-windows-gnu` with `-pc-windows-msvc` in
`src/Makevars.win` and updating `PKG_LIBS`. This option is intended for
existing MSVC development environments.

---

## 4.  P4 environment investigation summary  (2026-05)

P4 split into two passes.  The first pass discovered the development
machine could not build at all; the second pass (after switching to
MSYS2) uncovered three additional root-cause bugs that were only
surfaced once the compiler finally ran.  Both passes are documented
here in the order they actually happened.

### 4.1  Pass 1 — host toolchain unusable

- `cargo metadata` worked, `cargo build --lib hill_s` could compile
  source but failed at link time with:
  - MSVC target → `link.exe not found` (no C++ workload installed,
    despite `vswhere` reporting `D:\c++` as a VS install path; the
    directory was empty).
  - GNU (TDM-GCC 10.3) target → after applying the `libgcc_eh.a` mock
    the link step succeeded, but executing the resulting build-script
    binary failed with `ApplicationFailedException` (Windows
    "specified executable is not a valid Win32 application",
    `os error 193`), indicating PE-segment incompatibility between
    Rust's GNU sysroot and TDM 10.3 — *not* a missing-DLL issue.

**Decision**: install MSYS2 mingw-w64 (Option A), install
`stable-x86_64-pc-windows-gnu` via `rustup`, and pin the project to it
with a directory-level override so the system default (`msvc`) stays
untouched:

```pwsh
rustup target add   x86_64-pc-windows-gnu
rustup toolchain install stable-x86_64-pc-windows-gnu   # if not already installed
rustup override set stable-x86_64-pc-windows-gnu         # per-project pin, run inside F:\biotrade\LineaLinkR
```

### 4.2  Pass 2 — three cascading bugs once the compiler finally ran

After Pass 1 everything *started* building.  Three problems then
appeared in strict order; each is fixed upstream in this repo so a
fresh checkout on MSYS2 just works.

**Bug #1 · `f64 += f32` type mismatches in `lr_scoring.rs`
(`cargo test --lib hill_s` uncovered, 8 errors).**

`lr_scoring.rs` used `Vec<f64>` accumulators (for numerical
stability) but added `f32` contributions directly via
`sums[idx] += expr.values[nnz]` / `sums[base] += v * w`.  Rust does
NO implicit float widening; the code had never actually been compiled
(no `cargo test` had ever been run against this module before P4),
so the bug had been latent since the module was written.  Fixed in
three places (lines 158, 205, 536) with explicit `as f64` widening.
Semantics unchanged; numerics strictly improve (f64 accumulation of
f32 contributions is more precise than f32-only).

**Bug #2 · `CARGO_HOME = $(CURDIR)/.cargo` on exFAT
(`os error 87` on cargo tarball unpack).**

The original `Makevars.win` redirected `CARGO_HOME` to a project-local
`.cargo/` directory for clean-up hygiene.  But the project lives on an
**exFAT** drive (`F:\`), and cargo's tarball extractor calls `SetFileTime()`
with a timestamp precision / format that Windows' exFAT driver rejects
with `ERROR_INVALID_PARAMETER` (`os error 87`) — concretely:
`failed to set mtime for F:\biotrade\LineaLinkR\src\.cargo\registry\...\.cargo_vcs_info.json`.
Fix: `src/Makevars` and `src/Makevars.win` no longer override
`CARGO_HOME`; the default global cache at `%USERPROFILE%\.cargo`
(on `C:\`, NTFS) is used for unpacking, which also lets `R CMD INSTALL`
reuse artefacts from any prior `cargo build`.

**Bug #3 · libgcc_eh.a mock silently shadowing real toolchain library
(undefined references to `_Unwind_Resume` × dozens at final link).**

The `Makevars.win` stub originally created a zero-byte `libgcc_eh.a`
under `target/libgcc_mock/` and prepended that directory to
`LIBRARY_PATH` for every build — a safety net for the TDM-GCC layout
(§3 Option D).  Under MSYS2 mingw-w64 16.1.0, however, a real
`libgcc_eh.a` (11 726 bytes) lives at
`C:\msys64\mingw64\lib\gcc\x86_64-w64-mingw32\16.1.0\libgcc_eh.a`.
Because `LIBRARY_PATH` prepended the mock directory, `ld` resolved
`-lgcc_eh` to the empty stub instead of the real archive, exporting no
unwinding symbols and producing dozens of
`undefined reference to '_Unwind_Resume'` errors plus
`_Unwind_GetTextRelBase`, `_GCC_specific_handler`, etc.
Fix: the mock is now gated behind the env-var
`LINEALINKR_NEED_LIBGCC_EH_MOCK`; default off means MSYS2 / winlibs /
Rtools users never see it, and TDM users opt in explicitly (§3 Option D).

### 4.3  One-off rust 1.94 match-ergonomics incompatibility

`src/trajectory/pseudotime.rs:897` used `.filter(|(_, &x)| !x.is_nan())`,
which the rust 1.94 borrow-checker rejects as
"cannot explicitly dereference within an implicitly-borrowing pattern".
Changed to `.filter(|(_, x)| !x.is_nan())`; `x` is `&&f32`, and
`is_nan()` works through auto-deref.  Equivalent semantics, backwards
compatible to rust 1.65.  This is orthogonal to the three bugs above
and is documented here for reproducibility when the same machine is
rebuilt on an older rustc.

### 4.4  Outcome

After fixes #1–#3 + §4.3 the entire verification matrix passes on
MSYS2 mingw-w64 16.1.0 + rustup stable-gnu 1.94.1 + R 4.5.2:

| Step | Result |
|------|--------|
| `cargo test --lib hill_s`  (P0 lock tests)  | 4 / 4 PASS |
| `cargo test --lib`  (full lib regression)   | 9 / 9 PASS |
| `cargo build --release --features extendr`  | OK, 1 m 05 s |
| `R CMD INSTALL .`  (via Makevars.win)       | `* DONE (LineaLinkR)` |
| `library(LineaLinkR); TrajectoryDE(...)`    | end-to-end OK |
| `library(LineaLinkR); ComputePseudotimeFuzzy(...)` | end-to-end OK |

---

## 5.  Build commands

### Linux / macOS
```bash
R CMD INSTALL .
# or, just the Rust core (no R):
cargo test --lib
cargo build --release
```

### Windows (after picking a working toolchain from §3)

```pwsh
# ── One-time setup ────────────────────────────────────────────────────
# (assumes Option A: MSYS2 mingw-w64 already installed and on PATH; see §3)
rustup target add x86_64-pc-windows-gnu
rustup toolchain install stable-x86_64-pc-windows-gnu    # if missing
rustup override set stable-x86_64-pc-windows-gnu         # run inside the project dir

# ── Per-session PATH + env (if system PATH cannot be edited) ──────────
$env:PATH = 'C:\msys64\mingw64\bin;D:\R\R-4.5.3\bin\x64;' + $env:PATH
$env:R_HOME    = 'D:\R\R-4.5.3'
$env:LIBR_HOME = 'D:\R\R-4.5.3'

# ── Rust core only (no R, no extendr) ─────────────────────────────────
cargo test --lib

# ── Full extendr release build (no R) ─────────────────────────────────
cargo build --release --features extendr

# ── Full R-package install ────────────────────────────────────────────
# To a throwaway library (avoids the shared D:\R\win-library\4.5 DLL
# lock problem when other R sessions have LineaLinkR loaded):
$mylib = 'F:\biotrade\LineaLinkR\.tmp-rlib'
New-Item -ItemType Directory -Force -Path $mylib | Out-Null
R CMD INSTALL --library=$mylib .

# ── End-to-end smoke test ─────────────────────────────────────────────
Rscript -e "args <- commandArgs(trailingOnly=TRUE); .libPaths(c(args[1], .libPaths())); library(LineaLinkR); print(sort(getNamespaceExports('LineaLinkR')))" $mylib
```

### Legacy TDM-GCC path (opt-in only; see §3 Option D)

```pwsh
$env:LINEALINKR_NEED_LIBGCC_EH_MOCK = '1'
R CMD INSTALL --library=$mylib .
```

### Re-generating the extendr wrappers

The wrappers in `R/wrap__LineaLinkR.R` are **hand-written** and do not depend
on `rextendr`. Adding or removing `#[extendr]` functions requires synchronized
updates in three places:

1. `src/extendr_bindings.rs` → the `extendr_module!` block at the
   bottom must list every function.
2. `R/wrap__LineaLinkR.R` → add a corresponding `.Call(wrap__*)` shim
   with the same argument count and order as the `#[extendr]` fn.
3. `R/linealinkr.R` (and `NAMESPACE` if user-visible) → expose a
   public R-side wrapper that performs index/layout boundary
   conversion as documented in the file header.

Keeping these three in sync is checked at `R CMD check` time (a
missing shim turns into a runtime "object not found" on first call).

---

## 6.  Known good versions (development pinning)

| Component           | Minimum required | Verified on this machine (2026-05-11) |
|---------------------|------------------|----------------------------------------|
| R                   | ≥ 4.2            | 4.5.2 (also 4.5.3, binary-compatible)  |
| rustc               | ≥ 1.65           | 1.94.1 (stable-x86_64-pc-windows-gnu)  |
| cargo               | ≥ 1.65           | 1.93.1 (msvc default) / 1.94.1 (gnu)   |
| extendr-api         | 0.7              | 0.7.1                                   |
| libR-sys            | 0.7              | 0.7.1                                   |
| Rtools              | 4.4              | 4.5 (used by `R CMD INSTALL` for linking) |
| MSYS2 mingw-w64-gcc | ≥ 13             | 16.1.0                                  |
| MSYS2 mingw-w64-binutils | bundled    | bundled with `mingw-w64-x86_64-toolchain` |

The extendr / libR-sys row is the important one for long-term
stability: upgrading extendr across a major version (0.7 → 0.9) will
change the shape of `extendr_bindings.rs` and the hand-written shims
in `R/wrap__LineaLinkR.R`; do it in a dedicated commit with a full
§4.4 re-verification run.
