# LineaLinkR NEWS

## LineaLinkR 0.6.4

- `InferStartCellAttractor()` now exposes nearest and mean attractor distance
  separately and removes the duplicated distance term. Root scoring uses the
  nearest-attractor distance as a maximin separation criterion: a candidate
  cannot compensate for lying near one terminal basin by being far from another.
  The five-component weights make the former combined distance contribution
  explicit.
- Root selection now aggregates the five-component evidence by the median score
  of each inferred state, then chooses a central within-state kNN representative.
  This removes the previous top-cell component instability without using time,
  lineage-tracing, or benchmark labels.
- `InferRootEnsemble()` evaluates candidate root regions across neighbourhood,
  representation, and stratified-subsample perturbations. It reports
  `supported`, `weak`, or `ambiguous` direction and does not treat support as a
  calibrated probability.
- Blind entropy and commitment gradients are merged as one attractor-direction
  axis; coverage and rank stability are confidence diagnostics rather than
  direction evidence. A single blind axis cannot support a signed-direction
  claim.
- Stable root ensembles stop after the registered minimum resamples. Candidate
  roots share one Rust graph build, and kNN component labels plus nearest bridge
  searches use native code paths instead of repeated R graph traversals.
- The annotation-free root ensemble remains available as an ambiguity audit,
  but it failed the registered real-data direction gate and is no longer the
  production default. Production uses the maximin five-component attractor
  with expression-derived detected-gene potency, labelled as anchored evidence;
  no benchmark ordering label enters inference.
- Attractor absorption now uses a double-precision sparse transition, native
  kNN component labels, and vectorized distance and source-flow calculations.
  This preserves the reference absorption probabilities while removing the
  cell-wise Markov and graph-traversal bottlenecks.
- `ComputePseudotimeFuzzy()` is documented as the executable paper path:
  UMAP-style fuzzy edge weights followed by shortest-path distance.
- R package metadata now has one maintainer and includes the full manuscript
  author list.
- Pooled temporal scoring now exposes its production Rust bin boundaries and
  Hill scale. Fixed-bound sample rescoring reuses both quantities, and R-side
  timing features use the same Rust boundary implementation.
- New fork-local APIs map nearest sister lineages, subtract shared temporal
  changes, retain low-activity and incomplete-window failures as non-evaluable,
  and summarize sign support at the biological-sample level without a
  cell-derived p-value.
- Complete-grid fork contrasts now use vectorized grouped reductions instead
  of splitting one R data frame per LR trajectory. The output contract and
  values are unchanged, while the paul15 fork stage falls from 14.75 s to
  1.78 s in the registered local profile.
- Static LR permutations now accumulate cluster statistics only for genes
  referenced by the LR database. The full-transcriptome mean is still used for
  the Hill scale, and scores and permutation p-values are unchanged. On the
  registered dentategyrus profile (100 permutations), this reduces the static
  LR stage from 7.14 s to 1.17 s and total analysis time from 12.83 s to 7.36 s.

## LineaLinkR 0.6.2

- `ComputeTemporalLR()` and its intermediate variant now return a complete
  lineage-by-bin grid for prescreened LR contexts by default. Structural-invalid
  bins are `NA`; structurally valid expression-negative bins are explicit zero.
- Donor temporal effects, peak times, role specificity, and lag profiles consume
  the same complete-bin semantics used by FakeLR and temporal permutation.
- Donor bin mass and peak-time calculations now reuse the Rust-equivalent
  weighted equal-frequency boundaries.
- Cross-correlation lag ties no longer prefer the first negative shift; ties are
  direction-neutral and audited. Small circular-shift nulls enumerate unique
  states instead of repeatedly sampling the same shifts.
- Cluster-level label permutation recomputes detection fractions and applies the
  same `min_pct` gate as the observed score.
- Full block role rebuilds are labelled `conditional_role_stability`, reflecting
  reuse of the original discovery evidence.
- Provenance IDs retain the complete MD5 digest instead of a 64-bit truncation.

## LineaLinkR 0.6.1

- Provenance hashes now include sparse expression positions and values; FakeLR
  hashes include matching and null-quality parameters.
- Fate entropy no longer substitutes for missing assignment confidence in the
  structural eligibility gate.
- Adaptive temporal/FakeLR confirmation uses the same full LR and fake-candidate
  universe as screening, replaces complete stage results, and retains stage
  hashes and audits. Monte Carlo diagnostics use observed null counts.
- Donor identity inference accepts only block-specific FakeLR calibration;
  pooled identity p-values are annotation-only. Block FakeLR restores coverage
  and distinct-draw gates.
- One-sided temporal/identity and signed two-sided lag Stouffer formulas are
  separated. Temporal donor meta defaults to Fisher; fixed/random summaries are
  explicitly exploratory without validated sampling SEs.
- Role calibration columns merge correctly; lateral and bystander participate
  in bootstrap dominance. Row/cell resampling is labelled sensitivity, while
  only full block rebuild is formal.
- Cross-correlation preserves original missing-bin positions. The canonical API
  is `ComputeLigandReceptorLag()`; circular-shift nulls produce `p_lag/q_lag`.
- Spatial null output now provides `p_spatial/q_spatial`; raw adjacency remains
  orthogonal support rather than altering the primary discovery gate.
- Source-build exclusions cover all `.tmp-*` directories and release documents
  now reference 0.6.1.

## LineaLinkR 0.6.0

Full formal export surface: no experimental labels, no occupancy_support fallback,
hard FakeLR/perm thresholds, adaptive APIs formalized, ALGORITHMS.md contract.

## LineaLinkR 0.5.5

Bootstrap NA-replicate fix, MergeEvidence spatial gate, lag null observed denominator.

- **Bootstrap**: Wilson CI / win rates use `n_boot_valid`; status `insufficient_boot`.
- **MergeEvidence**: spatial gate on `identity_prioritized` / `fully_supported`;
  `temporal_prioritized` semantics fixed; `dual_layer_evaluable`.
- **Lag**: `n_lag_perm_observed` for permutation null denominator.
- **Role**: block bootstrap `use_intermediate` in `rebuild_context`.

## LineaLinkR 0.5.4

FakeLR permutation median, spatial block null, formal block role bootstrap, lag meta.

- **FakeLR**: `fake_null_median`; donor `identity_effect_null_centered` aligned with
  fake-draw median when `fake_null_per_block = TRUE`.
- **Spatial**: `block_label_permutation` null mode.
- **Role**: `BootstrapRoleInference(bootstrap_mode = "block")` + `rebuild_context`.
- **Lag**: `SummarizeLagByDonor(compute_lag_null=TRUE)`; `MetaAnalyzeLagEffects()`.

## LineaLinkR 0.5.3

Permutation-aligned temporal null median, lag profile null, identity Stouffer meta.

## LineaLinkR 0.5.2

Donor meta rewrite, role/lag fixes, spatial null validation (parallel 0.5.2 sprint).

- **Donor**: `effect_mode`, `temporal_effect_null_centered`, `temporal_null_per_block`,
  Stouffer/Fisher meta, `q_meta`.
- **Role/lag**: lineage specificity counts, `timing_source`, `lag_exceeds_threshold`,
  sensitivity `BootstrapRoleInference` + Wilson CI.
- **Spatial**: `ComputeSpatialAdjacencyNull()`, `NormalizeSpatialAdjacency()`,
  `FilterLRBySpatialSupport(null_mode=)`.
- **MergeEvidence**: `assignment_confidence` NA when not supplied; legacy entropy gate
  for structural eligibility when confidence is missing.

## LineaLinkR 0.5.1

P0 statistical hardening from external audit (IUT, complex evaluable, adaptive q,
donor evaluable filter, role dominant, spatial radius diagonal, RE meta fields).

## LineaLinkR 0.5.0

Single GB feature-complete release (supersedes 0.4.3–0.4.5 dev iterations).

- **Complex FakeLR**: cardinality-matched null across generic, edge, and network
  layers (≤8 subunits/side).
- **Donor identity**: per-block FakeLR via `ComputeTemporalEffectsBySample(
  fake_null_per_block = TRUE, ...)`.
- **Role**: Rust `transition_window`; lag via `EnrichTemporalScoresWithLRSides()`.
- **Spatial**: adjacency on `ComputeTemporalLR` and `MergeEvidence`.
- **MergeEvidence**: `p_fake_complex` in identity resolution.

Install from `dist/LineaLinkR_0.5.0.zip` (Windows) or `.tar.gz` (source).
