# LineaLinkR changelog

## 0.6.3 — Lag weight indexing and pooled donor family

- Fix `.weighted_complex_gene_mean()` to use caller-aligned local weights instead
  of re-indexing with global cell IDs (gene-level lag/LR side profiles).
- Donor rescoring and block temporal null evaluate the pooled `pair_idx × source
  × target` (and trajectory) hypothesis family via `requested_contexts` /
  `requested_trajectories`; structurally valid zero-expression donors score `0`
  rather than disappearing as all-`NA`.
- Rust trajectory curve builder guards out-of-range source/target/lineage indices
  with all-invalid bins instead of panicking.

## 0.6.2 — Complete temporal-curve contract

- Complete prescreened LR context grids distinguish structural missingness from
  valid zero expression and expose `structural_valid` / `expression_supported`.
- Donor rescoring uses complete curves and Rust-equivalent weighted bin bounds;
  pooled scores are never substituted for a missing block trajectory.
- Role scoring propagates nonevaluable rows as `NA` and includes valid zero-score
  lineages in specificity denominators.
- Cross-correlation tie handling is direction-neutral with explicit tie audit;
  circular-shift nulls enumerate the finite unique state space when possible.
- Cluster permutation now recomputes the observed detection gate.
- Block role bootstrap is explicitly conditional on the original evidence table.
- Provenance keeps the full MD5 digest; adaptive docs state that full-universe
  confirmation is not a performance shortcut.

## 0.6.1 — Statistical contract alignment

- Full sparse-matrix analysis hash and expanded FakeLR/role provenance.
- Assignment-confidence and fate-entropy semantics fully separated.
- Screen/confirm adaptive stages share one LR universe and replace complete
  result/audit/provenance fields with observed-count diagnostics.
- Pooled identity evidence prohibited from donor meta; formal block FakeLR
  coverage and uniqueness gates restored.
- Correct one-sided Stouffer for temporal/identity and signed two-sided Stouffer
  for lag; Fisher is the default temporal donor combination.
- Six-class role bootstrap and explicit row/cell sensitivity labels.
- Original-bin cross-correlation, circular-shift lag null, `q_lag`, and canonical
  ligand-receptor naming.
- Spatial `p_spatial/q_spatial` and removal of raw spatial gating from primary
  joint discovery.
- Clean source-package exclusions and regenerated documentation.

## 0.6.0 — Full formal export surface (no experimental, no occupancy fallback)

- **Removed silent degradation**: `ComputeTemporalEffectsBySample()` requires formal
  rescoring inputs; `occupancy_support` mode removed.
- **Hard thresholds**: `ComputeFakeLRNull` / `ComputeTrajectoryFakeLRNull` stop when
  `n_fake_per_real < 100`; block FakeLR requires `n_fake_per_real_block >= 100`.
- **Adaptive APIs formalized**: removed experimental warnings; documented as formal
  two-stage screen/confirm with BH on full family.
- **BootstrapRoleInference**: `role_stability_mode = "formal"` for all modes.
- **Lag null**: two-sided `abs` comparison for `p_lag`.
- **Donor defaults**: `n_perms_block = 199`, `n_fake_per_real_block = 199`,
  `temporal_null_per_block` default TRUE.
- **Docs**: `ALGORITHMS.md` — export contract for all 41 APIs.
- **Tests**: `test-formal-api-contract.R`.

## 0.5.5 — Bootstrap denominator, spatial gate alignment, lag null observed count

- **Bootstrap**: failed block/empty replicates excluded from win-rate and Wilson CI;
  `n_boot_valid` audit column; `insufficient_boot` when `< 2` valid replicates.
- **MergeEvidence**: `identity_prioritized` / `fully_supported` respect spatial
  eligibility when `spatial_adjacency` is supplied; `temporal_prioritized` no longer
  overwritten by variation-only column; `dual_layer_evaluable` audit column.
- **Role block bootstrap**: `rebuild_context$use_intermediate` + optional `evidence`;
  E2E test with `bootstrap_mode = "block"`.
- **Lag null**: `p_lag` denominator uses observed finite null draws (`n_lag_perm_observed`).
- **Spatial tests**: block-label permutation correctness + `block_labels` required.
- **Tests**: `test-calibration-gates.R`.

## 0.5.4 — FakeLR null median, spatial block null, formal role bootstrap, lag meta

- **FakeLR**: Rust exports `fake_null_median` (median fake-draw trajectory statistic);
  `identity_effect_null_centered = trajectory_stat - fake_null_median` on donor paths
  when block FakeLR calibration is available.
- **Spatial**: `null_mode = "block_label_permutation"` in
  `ComputeSpatialAdjacencyNull()` / `FilterLRBySpatialSupport()` (shuffle labels
  within `block_labels` strata).
- **Role bootstrap**: `BootstrapRoleInference(bootstrap_mode = "block")` resamples
  whole blocks with replacement and rebuilds role features via `rebuild_context`;
  `role_stability_mode = "formal"` for block mode.
- **Lag meta**: `SummarizeLagByDonor(compute_lag_null=TRUE)`; new
  `MetaAnalyzeLagEffects()` (default Stouffer on `p_lag`).
- **Tests**: `test-null-and-meta-calibration.R`.

## 0.5.3 — Permutation-aligned nulls and formal lag/identity inference

- **Rust temporal null**: export `temporal_null_median` (median permuted trajectory
  statistic) from `compute_temporal_permutation`.
- **Donor rescoring**: `temporal_effect_null_centered` aligned with permutation
  null when `temporal_null_per_block` (auto-enabled in formal donor-rescore mode);
  `temporal_null_source` audit column; block permutation errors surface warnings.
- **Lag**: `ComputeLigandTargetLag(compute_lag_null=TRUE)` profile permutation
  null → `p_lag`, `lag_null_median`, `lag_null_centered`.
- **Identity meta**: `identity_effect_null_centered` (normal quantile transform);
  `MetaAnalyzeIdentityEffects()` defaults to `method = "stouffer"` on `p_identity`.
- **Tests**: `test-calibration-algorithms.R` (605 total PASS).

## 0.5.2 — Donor meta, role/lag, spatial validation

### Donor meta
- `effect_mode` (`donor_rescore` vs `occupancy_support`); `temporal_effect_null_centered`
- Per-block temporal null (`temporal_null_per_block`); Stouffer/Fisher meta methods
- `q_meta` (BH on full trajectory family); `n_samples >= 2` for meta p

### Role / lag
- Lineage specificity counts; `n_evaluable_lineages >= 2` for formal roles
- `timing_source` parameter; `lag_exceeds_threshold`; soft-weighted lag profiles
- `BootstrapRoleInference` documented as sensitivity analysis + Wilson CI

### Spatial / hygiene
- `ComputeSpatialAdjacencyNull()`, `NormalizeSpatialAdjacency()`, `FilterLRBySpatialSupport(null_mode=)`
- `assignment_confidence` decoupled from `1 - entropy` (legacy entropy gate in MergeEvidence)
- DESCRIPTION author cleanup; experimental markers on adaptive APIs

### Tests
- `test-donor-meta.R`, `test-role-lag.R`, `test-spatial-null.R`

## 0.5.1 — P0 statistical hardening

Bug fixes from external audit; no new features.

- **IUT**: `p_edge_iu` / `p_network_iu` require both endpoint null layers
  evaluable (intersection-union test).
- **Complex**: fix `complex_evaluable` vector recycling.
- **Adaptive**: unified BH q on full trajectory family after screen/confirm;
  functions marked experimental.
- **Donor**: `evaluable == FALSE` rows filtered correctly; `BootstrapSamples`
  preserves bootstrap replicate multiplicity.
- **Role**: `dominant_role_like` includes lateral/bystander when main roles zero.
- **Spatial**: radius mode excludes self-cell on diagonal.
- **Meta**: random-effects mode populates primary `meta_*` from RE; FE in
  `meta_*_fixed`.
- **Docs**: missing Rd for lag/spatial exports; `stats`/`tools` in Imports.

## 0.5.0 — GB feature-complete (single release)

Consolidates all 0.4.x sandbox work into one installable release. Use **0.5.0**
going forward; intermediate 0.4.3–0.4.5 tags were iterative dev builds only.

### Statistical kernel (0.3.1+)

- FakeLR position-matched p-values; dual/triple null (`context_generic`,
  `edge_rewire`, `lr_network_rewire`, `all`/`triple`).
- Trajectory-level BH; `MergeEvidence` identity/temporal intersection gating.
- Adaptive permutation / adaptive FakeLR; donor meta (`MetaAnalyzeTemporalEffects`,
  `MetaAnalyzeIdentityEffects`, LOSO, bootstrap).

### GB narrative layer (0.4.0–0.5.0)

- Donor/sample effects: `ComputeTemporalEffectsBySample` with optional per-block
  rescoring and **`fake_null_per_block`** (block-stratified FakeLR identity).
- Role pipeline: `ComputeRoleFeatures` → `ComputeRoleInference` /
  `BootstrapRoleInference`; **`transition_window`** in Rust core.
- Ligand-target lag: `ComputeLigandTargetLag`, `EnrichTemporalScoresWithLRSides`,
  `SummarizeLagByDonor`.
- Spatial: `ComputeSpatialAdjacency`, `FilterLRBySpatialSupport`,
  **`ComputeTemporalLR(spatial_adjacency=)`**, `MergeEvidence(spatial_adjacency=)`.
- Complex LR: `complex_null_mode = "cardinality_matched"` up to **8 subunits/side**
  with **generic + edge + network** null layers (0.5.0).
- Provenance hashes on calibration tables.

### Not in scope (requires data / wet lab, not code-only)

- Independent biological validation, perturbation benchmark ground truth.
- Formal `n_fake_per_real >= 1000` publication runs on real cohorts.

## 0.4.2 and earlier

See git history for incremental 0.4.x notes. Superseded by 0.5.0.
