# Installing LineaLinkR (pre-built binary — no Rust)

The repository currently contains a legacy 0.6.0 Windows binary. It does not
contain the 0.6.2 statistical fixes and must not be used to reproduce
0.6.2 results. Build or publish a fresh platform binary before distributing a
no-Rust installation path.

## Requirements

| Tool | Notes |
|------|-------|
| R | **4.5.x recommended** on Windows (binary below was built with R 4.5.3) |
| Matrix | `install.packages("Matrix")` |

## Windows — local binary

After a 0.6.2 binary has been built into `dist/`:

```r
install.packages("Matrix")
install.packages("path/to/LineaLinkR/dist/LineaLinkR_0.6.2.zip",
                 repos = NULL, type = "win.binary")
library(LineaLinkR)
packageVersion("LineaLinkR")
```

With **pak**:

```r
install.packages("pak")
pak::pkg_install("Matrix")
pak::pkg_install("path/to/LineaLinkR/dist/LineaLinkR_0.6.2.zip")
```

## Linux / macOS

Pre-built binaries are platform-specific. When no matching
`dist/LineaLinkR_*` artifact exists, the alternatives are the source install in
[INSTALL.md](INSTALL.md) or a matching asset from the GitHub Release page.

## Verify (optional)

```r
testthat::test_local("path/to/LineaLinkR")
```

Smoke tests use synthetic data only.

## Source install cases

- Modified Rust code in `src/`
- An R version that does not match the binary (see `dist/BUILD_INFO.md`)
- Linux or macOS without a published platform binary

See [INSTALL.md](INSTALL.md) and [BUILD_NOTES.md](BUILD_NOTES.md).
