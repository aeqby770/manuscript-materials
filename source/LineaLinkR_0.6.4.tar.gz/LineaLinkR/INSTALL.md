# Installing LineaLinkR (source)

> The 0.6.2 release archive is a source package. See
> **[INSTALL-BINARY.md](INSTALL-BINARY.md)** for binary availability.

This document is for **developers** and platforms/R versions without a matching
binary. Installing from source compiles the Rust static library during
`R CMD INSTALL`.

## 1. Prerequisites

| Tool | Minimum version | Notes |
|------|-----------------|-------|
| R | 4.2 | Any recent release |
| Rust | 1.65 | `rustc` + `cargo` from [rustup](https://rustup.rs) |
| GNU make | — | Bundled with Rtools on Windows |
| Matrix (R) | any | `install.packages("Matrix")` before loading LineaLinkR |

## 2. Linux / macOS

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
cd LineaLinkR
R CMD INSTALL .
```

Maintainers can produce a Linux binary for reviewers:

```bash
bash scripts/build-binary.sh
# => dist/LineaLinkR_<version>.tar.gz
```

## 3. Windows

1. Install [R](https://cran.r-project.org/) and [Rtools](https://cran.r-project.org/bin/windows/Rtools/).
2. Install [Rust](https://rustup.rs) and `rustup target add x86_64-pc-windows-gnu`.
3. Install [MSYS2](https://www.msys2.org) MinGW-w64 toolchain; put `C:\msys64\mingw64\bin` first on `PATH`.
4. `R CMD INSTALL .` from the package root.

Maintainers — build reviewer zip:

```pwsh
pwsh scripts/build-binary.ps1
# => dist/LineaLinkR_<version>.zip
```

See [BUILD_NOTES.md](BUILD_NOTES.md) for `libgcc_eh` troubleshooting.

## 4. Optional: `pak` (source only)

```r
install.packages("pak")
pak::pkg_install("Matrix")
pak::pkg_install("path/to/LineaLinkR")   # still compiles Rust
```

For binaries with `pak`, use `INSTALL-BINARY.md`.

## 5. Common failures

| Symptom | Fix |
|---------|-----|
| `there is no package called 'Matrix'` | `install.packages("Matrix")` |
| `cargo: command not found` | Install Rust; or use `INSTALL-BINARY.md` |
| Windows `libgcc_eh` link error | `BUILD_NOTES.md` |
| Binary won't load | R version mismatch — use source install |

## 6. Running tests

```r
testthat::test_local("path/to/LineaLinkR")
```

Smoke tests use synthetic data only.
