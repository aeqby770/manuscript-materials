# LineaLinkR 0.6.4: algorithm and export contract

The core temporal and FakeLR paths follow the formal statistical contract. Advanced modules distinguish formal inference, exploratory effect summaries, and sensitivity analyses rather than assigning one label to every output.

## Blind root

`InferStartCellAuto()` retains the signed PC score as a diagnostic, while candidate selection uses `abs(score)` as the ordering quality. When candidates in opposite directions are within `min_delta`, the function returns `root_direction_status = "ambiguous_pc_sign"`; the sign of a PC or embedding coordinate therefore cannot silently determine the root. This flag does not validate biological direction. An independent root prior or external time information is still required for that interpretation.

`InferRootEnsemble()` generates candidates from both PC ends and cluster-MST leaves without treating PC signs or cluster identifiers as direction evidence. It rebuilds kNN graphs across `k`, the number of leading embedding dimensions, and within-cluster resampling, then computes coverage, pseudotime-rank stability, and available entropy, commitment, and potency gradients for each candidate. `root_support` is the frequency with which a candidate wins the perturbations, not a calibrated probability. If the evidence gap is insufficient, the result contains `direction_status = "ambiguous"`. Numeric pseudotime is returned only after a deterministic tie-break and does not establish biological direction.

## Core inference

`ComputeTemporalLR(return_complete_grid = TRUE)` expands every pre-screened LR by source, target, lineage, and bin. When `structural_valid = FALSE`, `score = NA`; when the structure is valid but the expression threshold is not met, `score = 0`. Donor, role, and lag layers use this complete representation and share `min_n_eff` with the calibration layer.

| Function | Testing unit | Null | Multiple correction |
|----------|--------------|------|---------------------|
| `ComputeTrajectoryFakeLRNull` | LR x source x target x lineage | Matched fake trajectories | BH on the `p_fake` family |
| `ComputeTemporalPermutation` | Same | Pseudotime permutation within strata | BH on the `p_temporal` family |
| `ComputeAdaptiveTrajectoryFakeLRNull` | Same | Two-stage screen/confirm | BH on the merged family |
| `ComputeAdaptiveTemporalPermutation` | Same | Two-stage permutation | BH on the merged family |
| `MergeEvidence` | Trajectory-key merge | Calibration tables from each layer | Layer-specific q values are computed in the calibration tables |
| `ComputeTemporalEffectsBySample` | Trajectory x block | Within-block rescoring plus permutation/FakeLR | Downstream meta-analysis BH |
| `MetaAnalyze*Effects` | Across blocks | One- or two-sided Stouffer or Fisher | `q_meta` |
| `ComputeLigandReceptorLag` | Trajectory | Circular-shift profile null | `p_lag`, `q_lag` |
| `BootstrapRoleInference` | Trajectory | Row/cell sensitivity or complete block rebuild | Stability proportion plus Wilson CI |

Adaptive confirmation reruns the complete LR universe to keep the statistical universe fixed. The implementation allocates precision across two stages; it does not claim a computational speed-up.

## Hard thresholds

- `ComputeFakeLRNull` and `ComputeTrajectoryFakeLRNull`: `n_fake_per_real >= 100` (1000+ is recommended for trajectory inference).
- `ComputeTemporalEffectsBySample`: `expr`, `celltypes`, `lr_db`, `block_labels`, `pseudotime`, and `lineage_weights` are required.
- Block-level FakeLR: `n_fake_per_real_block >= 100` (default 199).
- Temporal permutation: `min_perm_observed` and `min_perm_coverage` are enforced by `ComputeTemporalPermutation`.
- Cluster permutation recomputes detection fractions and applies the same `min_pct` gate as the observed statistic.

## Removed semantics

- `occupancy_support`: without formal inputs the function stops instead of silently reusing pooled bins.
- Pooled identity p-values are not entered into donor meta-analysis; fixed and random donor meta-analysis are exploratory effect summaries.

## MergeEvidence columns

- `fully_supported`: jointly evaluable and supported by `p_joint`; spatial support is an independent annotation.
- `prioritized_candidate`: structural gates pass and at least one calibration layer is supported (OR).
- `identity_prioritized`, `temporal_prioritized`, `temporal_variation_prioritized`, and `trajectory_strength_prioritized`: layer-specific prioritization columns.
- `dual_layer_evaluable`: both calibration layers are evaluable.

## Role

- `ComputeRoleInference`: formal `*_like` scores on `fully_supported` trajectories.
- `BootstrapRoleInference`: `row = "sensitivity"` and `cell = "timing_sensitivity"`; a complete block rebuild reports `conditional_role_stability` because FakeLR, temporal permutation, and `q_joint` are not rerun within every bootstrap replicate.

## Pseudotime graph and optional CCI injection

The paper and R API use `ComputePseudotimeFuzzy()` by default. It constructs UMAP-style locally adaptive fuzzy memberships from precomputed kNN distances and computes root-to-cell Dijkstra shortest paths with `distance / membership` as the edge cost. The raw-distance `compute_pseudotime` is an internal Rust alternative, not the default paper path. Cells unreachable from the root receive `NaN`, rather than being treated as late cells; finite values are normalized to `[0, 1]`.

The optional `inject_cci_weights_into_knn(cci_k)` shortens kNN edge distances for cell pairs with CCI probability using `d' = d / (1 + cci_k * p)`, bringing strongly communicating cells closer in the trajectory graph.

For confirmatory temporal analyses, `cci_k = 0` is required (the default). When enabled, CCI probabilities shape pseudotime, while the temporal permutation null only shuffles pseudotime and therefore does not remove that dependence. Values `cci_k > 0` are for exploratory analyses or sensitivity comparisons with the `cci_k = 0` result, not independent confirmation.

## Evidence decomposition: quantile-aligned profile correlation

Within each `(source, target, lineage, bin)` stratum, `EvidenceDecompBatch` sorts source and target cells separately by pseudotime. Each side is divided into `k = min(5, n_source, n_target)` equal-frequency micro-bins; ligand and receptor complex means are computed per bin and paired by quantile index to obtain Pearson `aligned_r`.

- This is quantile-rank alignment, not alignment within shared pseudotime intervals. If the two sides cover different pseudotime ranges, non-synchronous cells can be paired. Documentation and manuscripts should call it quantile-aligned profile correlation rather than shared pseudotime micro-bins.
- The output is descriptive: `z_score` is always `NaN`, and no p value or Fisher transformation is produced. With at most five bins, no formal significance test is applied. `evidence_sufficient` requires at least three bins per side, `n_eff >= 5`, and non-constant profiles.

## Temporal permutation: strata and p-value definition

- Two strata modes are available: `BlockCelltypeDominantLineage` (default), which permutes pseudotime within `(block, cell type, dominant lineage)`, and `BlockCelltype`, which permutes within `(block, cell type)`. With soft lineage weights, `BlockCelltype` is appropriate because a dominant-lineage stratum does not reproduce the null distribution of non-dominant lineage curves.
- The permutation p value is `(#{null >= observed} + 1) / (#evaluable_perm + 1)`. The denominator is the number of evaluable permutations, not the planned `n_perms`. Lower `perm_coverage` reduces resolution; `min_perm_observed` and `min_perm_coverage` provide explicit thresholds, and `perm_coverage` is included in the output.
- Bin-level p values use max-T, taking the largest permutation deviation across bins to control trajectory-level FWER.

## Numerical approximations and degenerate inputs

- Trajectory DE `t_pval` uses a normal approximation with Cornish-Fisher degrees-of-freedom shrinkage, `z = |t| * sqrt(1 - 1/(4 * df))`, rather than the exact t distribution. The approximation is adequate for `df >= 10`; near `min_cells` it is treated as exploratory and is followed by BH correction.
- Pearson handling differs for two degenerate-input paths by design. `ccc::rank::pearson_f64` returns `NaN` when variance is approximately zero or `n < 3`; `trajectory::pseudotime::pearson_f64` returns `0.0` (constant gene: `rho = 0`, `p = 1`). Downstream filtering follows the contract of each path.
- `fate_probabilities` iterates an absorbing-chain model. `directed_markov` must produce row-stochastic transitions and a route from every cell to at least one terminal; otherwise terminal probabilities can sum to less than one because unreached mass is not renormalized.

## Sister-lineage fork contrast (0.6.4)

`BuildSiblingContrastMap()` compares only the nearest sister lineages that share the longest root-to-terminal path prefix. All tied nearest sisters are retained; unrelated distal lineages are not included as background.

`ComputeTemporalLRWithIntermediate()` returns the `bin_bounds` and `hill_scale` used by the Rust production scores. `ComputeTemporalLRFixedBounds()` rescales each biological sample with these pooled quantities; samples do not re-estimate quantile boundaries or the Hill scale independently. R timing features also call Rust `compute_bin_bounds` so that R double precision and Rust `f32` accumulation cannot shift a quantile cut by one bin.

For focal lineage fork bin `b*` and window width `w`, the fork bin itself is excluded from the pre- and post-fork means:

`B_pre = {b* - w, ..., b* - 1}`

`B_post = {b* + 1, ..., b* + w}`

The effective weight of bin `b` is `w_b = min(n_eff,b, Q_0.95(n_eff))`. The weighted activity mean is

`A_W = sum_(b in W)(w_b S_b) / sum_(b in W) w_b`.

The within-lineage change is `Delta_f = A_post,f - A_pre,f`. The change for each nearest sister is normalized with the same truncated effective weights, giving

`C_f = Delta_f - sum_s(omega_s Delta_s) / sum_s omega_s`.

`C_f` removes the global temporal trend shared by sister lineages but remains an observational contrast, not a causal effect. Structurally invalid bins are missing; structurally valid bins that fail the expression gate retain the production value `score = 0`. If a pre- or post-fork window is incomplete, activity is below `activity_floor`, or no sister is evaluable, `evaluable = FALSE` and the contrast is `NA` rather than zero-filled.

Additional descriptive axes are:

- `pre_fork_enrichment = A_pre / (A_pre + A_post + 1e-12)`;
- `fork_locality = A_fork / (A_pre + A_fork + A_post + 1e-12)`;
- `post_fork_persistence = 1 - sd(S_post) / (abs(mean(S_post)) + sd(S_post) + 1e-12)`.

These columns are not automatically converted into instructive, feedback, or other mechanism labels.

`SummarizeForkContrastsBySample()` resamples at the sample level. `median_contrast` is the median sample contrast; `positive_sample_fraction` and `negative_sample_fraction` are reported separately; `sample_support` is the fraction of samples sharing the median direction. A bootstrap CI for the sample median is computed only when `n_samples >= 2`. Single-sample results are labelled `single_sample_descriptive` and do not receive p values based on cell-level pseudoreplication.
