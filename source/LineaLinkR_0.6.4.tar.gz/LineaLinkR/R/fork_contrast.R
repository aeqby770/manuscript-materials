# Fork-local sibling-lineage evidence.

#' Map each lineage to its nearest sibling lineage or lineages.
#'
#' Nearest siblings are the other root-to-terminal paths sharing the longest
#' prefix with a focal path. Ties are retained as separate rows.
#'
#' @param lineage_paths list of positive integer root-to-terminal cluster paths.
#' @return Data frame with focal and sibling lineage indices, fork cluster, and
#'   shared-prefix length.
#' @export
BuildSiblingContrastMap <- function(lineage_paths) {
  if (!is.list(lineage_paths) || length(lineage_paths) < 2L) {
    stop("`lineage_paths` must contain at least two paths", call. = FALSE)
  }
  paths <- lapply(seq_along(lineage_paths), function(i) {
    path <- .as_integerish(lineage_paths[[i]], sprintf("lineage_paths[[%d]]", i))
    if (!length(path) || any(path < 1L)) {
      stop("lineage paths must be non-empty positive integer vectors",
           call. = FALSE)
    }
    path
  })
  roots <- vapply(paths, `[[`, integer(1L), 1L)
  if (length(unique(roots)) != 1L) {
    stop("all lineage paths must have one common root", call. = FALSE)
  }
  keys <- vapply(paths, paste, collapse = ">", character(1L))
  if (anyDuplicated(keys)) {
    stop("duplicate lineage path", call. = FALSE)
  }

  rows <- lapply(seq_along(paths), function(focal) {
    siblings <- setdiff(seq_along(paths), focal)
    prefix <- vapply(siblings, function(sibling) {
      .common_prefix_length(paths[[focal]], paths[[sibling]])
    }, integer(1L))
    keep <- siblings[prefix == max(prefix)]
    kept_prefix <- prefix[prefix == max(prefix)]
    data.frame(
      focal_lineage = as.integer(focal),
      sibling_lineage = as.integer(keep),
      fork_cluster = as.integer(paths[[focal]][kept_prefix]),
      shared_prefix_length = as.integer(kept_prefix),
      stringsAsFactors = FALSE
    )
  })
  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  out
}

.common_prefix_length <- function(a, b) {
  n <- min(length(a), length(b))
  mismatch <- which(a[seq_len(n)] != b[seq_len(n)])
  if (length(mismatch) == 0L) n else mismatch[[1L]] - 1L
}

#' Compute fork-local contrasts against nearest sibling lineages.
#'
#' The function compares weighted mean LR activity in adjacent pre- and
#' post-fork windows, then subtracts the corresponding change in the nearest
#' sibling lineage. The result is descriptive and is not a causal effect.
#'
#' @param temporal_scores Temporal LR score table.
#' @param bif_df Lineage-specific fork bins from `FindBifurcationBins()`.
#' @param sibling_map Output from `BuildSiblingContrastMap()`.
#' @param sample_col Optional sample identifier column.
#' @param window_bins Number of bins on each side of the fork.
#' @param activity_floor Minimum activity required for evaluation.
#' @param min_n_eff Minimum row-level effective cell count.
#' @return One row per LR trajectory and focal lineage.
#' @export
ComputeForkContrasts <- function(temporal_scores, bif_df, sibling_map,
                                 sample_col = NULL, window_bins = 2L,
                                 activity_floor = 1e-4, min_n_eff = 5) {
  score_required <- c(
    "pair_idx", "source", "target", "lineage", "bin", "score"
  )
  bif_required <- c("lineage", "b_star", "reason")
  sibling_required <- c(
    "focal_lineage", "sibling_lineage", "fork_cluster",
    "shared_prefix_length"
  )
  if (!is.data.frame(temporal_scores) ||
      !all(score_required %in% colnames(temporal_scores))) {
    stop("`temporal_scores` is missing required columns", call. = FALSE)
  }
  if (!is.data.frame(bif_df) ||
      !all(bif_required %in% colnames(bif_df))) {
    stop("`bif_df` is missing required columns", call. = FALSE)
  }
  if (!is.data.frame(sibling_map) ||
      !all(sibling_required %in% colnames(sibling_map))) {
    stop("`sibling_map` is missing required columns", call. = FALSE)
  }
  if (!is.null(sample_col) &&
      (length(sample_col) != 1L ||
       !sample_col %in% colnames(temporal_scores))) {
    stop("`sample_col` must name one column in `temporal_scores`",
         call. = FALSE)
  }
  window_bins <- .as_integerish(window_bins, "window_bins")
  if (length(window_bins) != 1L || window_bins < 1L) {
    stop("`window_bins` must be one positive integer", call. = FALSE)
  }
  activity_floor <- as.numeric(activity_floor)
  min_n_eff <- as.numeric(min_n_eff)
  if (length(activity_floor) != 1L || !is.finite(activity_floor) ||
      activity_floor < 0) {
    stop("`activity_floor` must be one finite value >= 0", call. = FALSE)
  }
  if (length(min_n_eff) != 1L || !is.finite(min_n_eff) || min_n_eff < 0) {
    stop("`min_n_eff` must be one finite value >= 0", call. = FALSE)
  }
  if (anyDuplicated(bif_df$lineage)) {
    stop("`bif_df$lineage` must be unique", call. = FALSE)
  }

  scores <- data.table::as.data.table(data.table::copy(temporal_scores))
  n_eff_source <- if ("n_eff_cells" %in% colnames(scores)) {
    "reported"
  } else {
    scores$n_eff_cells <- 1
    "unavailable"
  }
  if ("structural_valid" %in% colnames(scores)) {
    scores$structurally_valid <- as.logical(scores$structural_valid)
  } else if (!"structurally_valid" %in% colnames(scores)) {
    scores$structurally_valid <- TRUE
  }
  scores[, b_star := bif_df$b_star[match(lineage, bif_df$lineage)]]
  scores[, bifurcation_reason := bif_df$reason[
    match(lineage, bif_df$lineage)
  ]]
  group_cols <- c(
    "pair_idx", "source", "target", "lineage",
    if (!is.null(sample_col)) sample_col
  )
  scores[, valid_bif := !is.na(b_star) & bifurcation_reason == "crossing"]
  scores[, valid := is.finite(score) & is.finite(n_eff_cells) &
           n_eff_cells >= min_n_eff & !is.na(structurally_valid) &
           structurally_valid]
  scores[, cap := stats::quantile(
    n_eff_cells[valid], 0.95, na.rm = TRUE, names = FALSE
  ), by = group_cols]
  scores[, w_eff := pmin(n_eff_cells, cap)]
  scores[, pre := valid & valid_bif &
           bin >= b_star - window_bins & bin <= b_star - 1L]
  scores[, post := valid & valid_bif &
           bin >= b_star + 1L & bin <= b_star + window_bins]
  scores[, fork := valid & valid_bif & bin == b_star]

  focal <- scores[, .(
    b_star = data.table::first(data.table::fifelse(
      valid_bif, as.integer(b_star), NA_integer_
    )),
    valid_bif = data.table::first(valid_bif),
    pre_count = sum(pre),
    pre_numerator = sum(data.table::fifelse(pre, score * w_eff, 0)),
    pre_denominator = sum(data.table::fifelse(pre, w_eff, 0)),
    fork_count = sum(fork),
    fork_numerator = sum(data.table::fifelse(fork, score * w_eff, 0)),
    fork_denominator = sum(data.table::fifelse(fork, w_eff, 0)),
    post_count = sum(post),
    post_numerator = sum(data.table::fifelse(post, score * w_eff, 0)),
    post_denominator = sum(data.table::fifelse(post, w_eff, 0)),
    post_score_sum = sum(data.table::fifelse(post, score, 0)),
    post_score_sum_squares = sum(data.table::fifelse(post, score * score, 0)),
    n_pre_bins = data.table::uniqueN(bin[pre]),
    n_post_bins = data.table::uniqueN(bin[post]),
    effective_weight = sum(data.table::fifelse(valid, w_eff, 0))
  ), by = group_cols]
  focal[, pre_activity := data.table::fifelse(
    pre_count > 0L, pre_numerator / pre_denominator, NA_real_
  )]
  focal[, fork_activity := data.table::fifelse(
    fork_count > 0L, fork_numerator / fork_denominator, NA_real_
  )]
  focal[, post_activity := data.table::fifelse(
    post_count > 0L, post_numerator / post_denominator, NA_real_
  )]
  focal[, post_mean := data.table::fifelse(
    post_count > 0L, post_score_sum / post_count, NA_real_
  )]
  focal[, post_sd := data.table::fifelse(
    post_count > 1L,
    sqrt(pmax(
      0,
      (post_score_sum_squares - post_score_sum * post_score_sum / post_count) /
        (post_count - 1L)
    )),
    NA_real_
  )]
  focal[, activity_strength := pmax(
    pre_activity, fork_activity, post_activity, na.rm = TRUE
  )]
  focal[!is.finite(activity_strength), activity_strength := NA_real_]
  focal[, reason := data.table::fifelse(
    !valid_bif,
    "invalid_bifurcation",
    data.table::fifelse(
      n_pre_bins != window_bins,
      "insufficient_pre_bins",
      data.table::fifelse(
        n_post_bins != window_bins,
        "insufficient_post_bins",
        data.table::fifelse(
          !is.finite(activity_strength) | activity_strength < activity_floor,
          "below_activity_floor",
          "evaluable"
        )
      )
    )
  )]
  focal[, evaluable := reason == "evaluable"]
  focal[, post_fork_change := data.table::fifelse(
    evaluable, post_activity - pre_activity, NA_real_
  )]
  focal[, pre_fork_enrichment := pre_activity /
          (pre_activity + post_activity + 1e-12)]
  focal[, fork_locality := fork_activity /
          (pre_activity + fork_activity + post_activity + 1e-12)]
  focal[, post_fork_persistence := data.table::fifelse(
    is.finite(post_sd),
    1 - post_sd / (abs(post_mean) + post_sd + 1e-12),
    NA_real_
  )]
  focal[, `:=`(
    n_eff_source = n_eff_source,
    inference_unit = data.table::fifelse(
      is.null(sample_col),
      "pooled_cells_descriptive",
      "sample_rescore_descriptive"
    )
  )]
  focal[, c(
    "valid_bif", "pre_count", "pre_numerator", "pre_denominator",
    "fork_count", "fork_numerator", "fork_denominator", "post_count",
    "post_numerator", "post_denominator", "post_score_sum",
    "post_score_sum_squares", "post_mean", "post_sd"
  ) := NULL]
  data.table::setorderv(focal, group_cols)

  mapped <- merge(
    focal, data.table::as.data.table(data.table::copy(sibling_map)),
    by.x = "lineage", by.y = "focal_lineage", all.x = TRUE,
    sort = FALSE, allow.cartesian = TRUE
  )
  sibling_keys <- c("pair_idx", "source", "target", "lineage")
  if (!is.null(sample_col)) sibling_keys <- c(sibling_keys, sample_col)
  sibling <- focal[, c(
    sibling_keys, "post_fork_change", "effective_weight", "evaluable"
  ), with = FALSE]
  data.table::setnames(
    sibling,
    c("lineage", "post_fork_change", "effective_weight", "evaluable"),
    c(
      "sibling_lineage", "sibling_post_fork_change",
      "sibling_effective_weight", "sibling_evaluable"
    )
  )
  join_keys <- c("pair_idx", "source", "target", "sibling_lineage")
  if (!is.null(sample_col)) join_keys <- c(join_keys, sample_col)
  mapped <- merge(mapped, sibling, by = join_keys, all.x = TRUE, sort = FALSE)
  focal_id_cols <- c(group_cols, "reason")
  mapped[, sibling_valid := !is.na(sibling_evaluable) & sibling_evaluable &
           is.finite(sibling_post_fork_change) &
           is.finite(sibling_effective_weight) & sibling_effective_weight > 0]
  mapped[, sibling_cap := stats::quantile(
    sibling_effective_weight[sibling_valid], 0.95,
    names = FALSE, na.rm = TRUE
  ), by = focal_id_cols]
  mapped[, sibling_weight := pmin(sibling_effective_weight, sibling_cap)]
  sibling_summary <- mapped[, .(
    sibling_valid_count = sum(sibling_valid),
    sibling_numerator = sum(data.table::fifelse(
      sibling_valid, sibling_post_fork_change * sibling_weight, 0
    )),
    sibling_denominator = sum(data.table::fifelse(
      sibling_valid, sibling_weight, 0
    ))
  ), by = focal_id_cols]
  sibling_summary[, sibling_change := data.table::fifelse(
    sibling_valid_count > 0L,
    sibling_numerator / sibling_denominator,
    NA_real_
  )]
  sibling_summary[, c(
    "sibling_valid_count", "sibling_numerator", "sibling_denominator"
  ) := NULL]
  out <- merge(
    focal, sibling_summary,
    by = focal_id_cols, all.x = TRUE, sort = FALSE
  )
  out[, sibling_contrast := data.table::fifelse(
    evaluable & is.finite(sibling_change),
    post_fork_change - sibling_change,
    NA_real_
  )]
  out[evaluable & !is.finite(sibling_change), `:=`(
    evaluable = FALSE,
    reason = "no_evaluable_sibling"
  )]
  data.table::setorderv(out, group_cols)
  out <- out[, c(
    group_cols, "b_star", "pre_activity", "fork_activity",
    "post_activity", "post_fork_change", "sibling_change",
    "sibling_contrast", "activity_strength", "pre_fork_enrichment",
    "fork_locality", "post_fork_persistence", "n_pre_bins",
    "n_post_bins", "effective_weight", "evaluable", "reason",
    "n_eff_source", "inference_unit"
  ), with = FALSE]
  data.frame(out, stringsAsFactors = FALSE)
}

#' Summarize fork contrasts across biological samples.
#'
#' Samples, not cells, are the resampling unit. The function reports sign
#' fractions and a bootstrap interval for the sample median, but no cell-level
#' inferential p-value.
#'
#' @param sample_contrasts One evaluable contrast row per trajectory and sample.
#' @param n_boot Number of sample bootstrap replicates.
#' @param seed Random seed.
#' @return Sample-level descriptive summary.
#' @export
SummarizeForkContrastsBySample <- function(sample_contrasts,
                                           n_boot = 999L,
                                           seed = 12345L) {
  required <- c(
    "pair_idx", "source", "target", "lineage", "block_label",
    "sibling_contrast", "evaluable"
  )
  if (!is.data.frame(sample_contrasts) ||
      !all(required %in% colnames(sample_contrasts))) {
    stop("`sample_contrasts` is missing required columns", call. = FALSE)
  }
  n_boot <- .validate_positive_int(n_boot, "n_boot", min = 1L)
  seed <- .validate_seed(seed)
  x <- sample_contrasts[
    sample_contrasts$evaluable %in% TRUE &
      is.finite(sample_contrasts$sibling_contrast),
    , drop = FALSE
  ]
  x <- as.data.frame(x, stringsAsFactors = FALSE)
  if (!nrow(x)) {
    stop("no evaluable sample contrasts", call. = FALSE)
  }
  by <- c("pair_idx", "source", "target", "lineage")
  key <- interaction(x[by], drop = TRUE, lex.order = TRUE)
  groups <- split(x, key)
  duplicated_samples <- vapply(groups, function(g) {
    anyDuplicated(g$block_label) > 0L
  }, logical(1L))
  if (any(duplicated_samples)) {
    stop("each trajectory must have at most one row per `block_label`",
         call. = FALSE)
  }
  set.seed(seed)
  rows <- lapply(groups, function(g) {
    values <- as.numeric(g$sibling_contrast)
    n_samples <- length(values)
    median_contrast <- stats::median(values)
    positive_fraction <- mean(values > 0)
    negative_fraction <- mean(values < 0)
    sample_support <- if (median_contrast > 0) {
      positive_fraction
    } else if (median_contrast < 0) {
      negative_fraction
    } else {
      max(positive_fraction, negative_fraction)
    }
    boot <- if (n_samples >= 2L) {
      replicate(
        n_boot,
        stats::median(sample(values, n_samples, replace = TRUE))
      )
    } else {
      numeric()
    }
    ci <- if (length(boot)) {
      stats::quantile(
        boot, c(0.025, 0.975), names = FALSE, na.rm = TRUE
      )
    } else {
      c(NA_real_, NA_real_)
    }
    cbind(
      g[1L, by, drop = FALSE],
      data.frame(
        median_contrast = median_contrast,
        sample_support = sample_support,
        positive_sample_fraction = positive_fraction,
        negative_sample_fraction = negative_fraction,
        n_samples = n_samples,
        ci_low = ci[[1L]],
        ci_high = ci[[2L]],
        inference_unit = if (n_samples >= 2L) {
          "biological_sample_bootstrap"
        } else {
          "single_sample_descriptive"
        },
        stringsAsFactors = FALSE
      )
    )
  })
  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  out
}

#' Compose fork-local evidence without assigning mechanistic roles.
#'
#' Missing response or sample support remains missing rather than being imputed
#' as zero. All merges use the complete LR trajectory key.
#'
#' @param fork_contrasts Output from `ComputeForkContrasts()`.
#' @param response_support Optional receiver-response evidence table.
#' @param sample_support Optional output from
#'   `SummarizeForkContrastsBySample()`.
#' @return Fork evidence table with an explicit completeness label.
#' @export
ComposeForkEvidence <- function(fork_contrasts, response_support = NULL,
                                sample_support = NULL) {
  key <- c("pair_idx", "source", "target", "lineage")
  fork_required <- c(
    key, "activity_strength", "pre_fork_enrichment", "fork_locality",
    "post_fork_change", "sibling_contrast", "post_fork_persistence",
    "evaluable"
  )
  if (!is.data.frame(fork_contrasts) ||
      !all(fork_required %in% colnames(fork_contrasts))) {
    stop("`fork_contrasts` is missing required columns", call. = FALSE)
  }
  out <- fork_contrasts
  out$.input_order <- seq_len(nrow(out))
  if (!is.null(response_support)) {
    response_required <- c(key, "receiver_response_support")
    if (!is.data.frame(response_support) ||
        !all(response_required %in% colnames(response_support))) {
      stop("`response_support` is missing required columns", call. = FALSE)
    }
    if (anyDuplicated(response_support[key])) {
      stop("`response_support` trajectory keys must be unique",
           call. = FALSE)
    }
    out <- merge(
      out,
      response_support[, response_required, drop = FALSE],
      by = key, all.x = TRUE, sort = FALSE
    )
  } else {
    out$receiver_response_support <- NA_real_
  }
  if (!is.null(sample_support)) {
    sample_required <- c(key, "sample_support")
    if (!is.data.frame(sample_support) ||
        !all(sample_required %in% colnames(sample_support))) {
      stop("`sample_support` is missing required columns", call. = FALSE)
    }
    if (anyDuplicated(sample_support[key])) {
      stop("`sample_support` trajectory keys must be unique", call. = FALSE)
    }
    sample_data <- sample_support
    sample_inference_index <- match(
      "inference_unit", colnames(sample_data), nomatch = 0L
    )
    if (sample_inference_index > 0L) {
      colnames(sample_data)[sample_inference_index] <-
        "sample_inference_unit"
    }
    sample_cols <- unique(c(
      key,
      intersect(
        c(
          "median_contrast", "sample_support",
          "positive_sample_fraction", "negative_sample_fraction",
          "n_samples", "ci_low", "ci_high", "sample_inference_unit"
        ),
        colnames(sample_data)
      )
    ))
    collisions <- intersect(
      setdiff(sample_cols, key),
      colnames(out)
    )
    if (length(collisions)) {
      stop("sample evidence columns already exist in `fork_contrasts`",
           call. = FALSE)
    }
    out <- merge(
      out,
      sample_data[, sample_cols, drop = FALSE],
      by = key, all.x = TRUE, sort = FALSE
    )
  } else if (!"sample_support" %in% colnames(out)) {
    out$sample_support <- NA_real_
  }
  response_present <- is.finite(out$receiver_response_support)
  sample_present <- is.finite(out$sample_support)
  out$evidence_completeness <- ifelse(
    response_present & sample_present,
    "fork+response+sample",
    ifelse(
      response_present,
      "fork+response",
      ifelse(sample_present, "fork+sample", "fork_only")
    )
  )
  out <- out[order(out$.input_order), , drop = FALSE]
  out$.input_order <- NULL
  rownames(out) <- NULL
  out
}
