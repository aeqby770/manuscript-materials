test_that("BuildSiblingContrastMap uses the nearest shared fork", {
  paths <- list(c(1L, 2L, 3L), c(1L, 2L, 4L), c(1L, 5L, 6L))
  out <- BuildSiblingContrastMap(paths)

  expect_true(all(c(
    "focal_lineage", "sibling_lineage", "fork_cluster",
    "shared_prefix_length"
  ) %in% colnames(out)))
  expect_equal(out$sibling_lineage[out$focal_lineage == 1L], 2L)
  expect_equal(out$sibling_lineage[out$focal_lineage == 2L], 1L)
  expect_setequal(out$sibling_lineage[out$focal_lineage == 3L], c(1L, 2L))
  expect_equal(unique(out$fork_cluster[out$focal_lineage == 1L]), 2L)
  expect_equal(unique(out$fork_cluster[out$focal_lineage == 3L]), 1L)
})

test_that("BuildSiblingContrastMap rejects inconsistent roots and duplicates", {
  expect_error(
    BuildSiblingContrastMap(list(c(1L, 2L), c(9L, 3L))),
    "common root"
  )
  expect_error(
    BuildSiblingContrastMap(list(c(1L, 2L), c(1L, 2L))),
    "duplicate lineage path"
  )
})

test_that("shared temporal trends cancel in sibling contrast", {
  f <- make_fork_score_fixture()
  out <- ComputeForkContrasts(
    f$scores, f$bif, f$sibling,
    window_bins = 2L, min_n_eff = 5
  )
  row <- out[out$pair_idx == 1L & out$lineage == 1L, ]
  expect_equal(row$sibling_contrast, 0, tolerance = 1e-12)
  expect_gt(row$post_fork_change, 0)
})

test_that("branch-specific activation remains after sibling subtraction", {
  f <- make_fork_score_fixture()
  out <- ComputeForkContrasts(
    f$scores, f$bif, f$sibling,
    window_bins = 2L, min_n_eff = 5
  )
  focal <- out[out$pair_idx == 2L & out$lineage == 1L, ]
  sibling <- out[out$pair_idx == 2L & out$lineage == 2L, ]
  expect_gt(focal$sibling_contrast, 0)
  expect_lt(sibling$sibling_contrast, 0)
  expect_gt(abs(focal$sibling_contrast), 1)
})

test_that("data.table scores retain all tied nearest siblings", {
  f <- make_fork_score_fixture()
  third <- f$scores[f$scores$lineage == 1L, , drop = FALSE]
  third$lineage <- 3L
  scores <- data.table::as.data.table(rbind(f$scores, third))
  bif <- rbind(
    f$bif,
    transform(f$bif[f$bif$lineage == 1L, , drop = FALSE], lineage = 3L)
  )
  sibling <- BuildSiblingContrastMap(list(
    c(1L, 2L), c(1L, 3L), c(1L, 4L)
  ))

  out <- ComputeForkContrasts(
    scores, bif, sibling,
    window_bins = 2L, min_n_eff = 5
  )

  expect_equal(nrow(out), 9L)
  expect_setequal(out$lineage, 1:3)
})

test_that("complete fork grids avoid per-trajectory R splitting", {
  scores <- expand.grid(
    pair_idx = seq_len(1000L),
    source = 1L,
    target = 2L,
    lineage = 1:2,
    bin = 1:12,
    KEEP.OUT.ATTRS = FALSE,
    stringsAsFactors = FALSE
  )
  scores$score <- ((scores$pair_idx + scores$lineage + scores$bin) %% 17) / 17
  scores$n_eff_cells <- 20
  scores$structural_valid <- TRUE
  bif <- data.frame(
    lineage = 1:2,
    b_star = 6L,
    reason = "crossing"
  )
  sibling <- data.frame(
    focal_lineage = 1:2,
    sibling_lineage = 2:1,
    fork_cluster = 1L,
    shared_prefix_length = 1L
  )

  elapsed <- system.time({
    out <- ComputeForkContrasts(
      scores, bif, sibling,
      window_bins = 2L, min_n_eff = 5
    )
  })[["elapsed"]]

  expect_equal(nrow(out), 2000L)
  expect_lt(elapsed, 3)
})

test_that("low activity and incomplete windows are not high-confidence evidence", {
  f <- make_fork_score_fixture()
  f$scores$score[f$scores$pair_idx == 3L] <- 1e-8
  out <- ComputeForkContrasts(
    f$scores, f$bif, f$sibling,
    window_bins = 2L, activity_floor = 1e-4,
    min_n_eff = 5
  )
  low <- out[out$pair_idx == 3L, ]
  expect_true(all(!low$evaluable))
  expect_true(all(low$reason == "below_activity_floor"))

  f$bif$b_star[1L] <- 1L
  bad <- ComputeForkContrasts(
    f$scores, f$bif, f$sibling,
    window_bins = 2L, min_n_eff = 5
  )
  expect_true(any(bad$reason == "insufficient_pre_bins"))
})

test_that("fork contrast respects the production structural-valid gate", {
  f <- make_fork_score_fixture()
  colnames(f$scores)[colnames(f$scores) == "structurally_valid"] <-
    "structural_valid"
  f$scores$structural_valid[
    f$scores$pair_idx == 1L & f$scores$lineage == 1L &
      f$scores$bin %in% 1:2
  ] <- FALSE
  out <- ComputeForkContrasts(
    f$scores, f$bif, f$sibling,
    window_bins = 2L, min_n_eff = 5
  )
  row <- out[out$pair_idx == 1L & out$lineage == 1L, ]
  expect_false(row$evaluable)
  expect_equal(row$reason, "insufficient_pre_bins")
})

test_that("fixed pooled bounds reproduce pooled temporal scores", {
  f <- make_temporal_fixture()
  pooled <- ComputeTemporalLRWithIntermediate(
    f$x, f$ct, f$lr_db, f$pt, f$lw,
    n_bins = 4L, min_pct = 0, min_n_eff = 0.1,
    return_complete_grid = TRUE
  )
  bounds <- attr(pooled$scores, "bin_bounds")
  fixed <- ComputeTemporalLRFixedBounds(
    f$x, f$ct, f$lr_db, f$pt, f$lw,
    bin_bounds = bounds,
    hill_scale = attr(pooled$scores, "hill_scale"),
    n_bins = 4L, min_pct = 0, min_n_eff = 0.1,
    return_complete_grid = TRUE
  )
  key <- c("pair_idx", "source", "target", "lineage", "bin")
  a <- pooled$scores[do.call(order, pooled$scores[key]), ]
  b <- fixed[do.call(order, fixed[key]), ]
  expect_equal(a[key], b[key])
  expect_equal(a$score, b$score, tolerance = 1e-7)
})

test_that("requested contexts accept data.table input", {
  f <- make_temporal_fixture()
  requested <- data.table::data.table(
    pair_idx = 1L,
    source = 1L,
    target = 2L
  )
  out <- ComputeTemporalLRWithIntermediate(
    f$x, f$ct, f$lr_db, f$pt, f$lw,
    n_bins = 4L, min_pct = 0, min_n_eff = 0.1,
    requested_contexts = requested
  )
  expect_true(nrow(out$scores) > 0L)
})

test_that("R feature engineering uses production Rust bin boundaries", {
  f <- make_temporal_fixture()
  pooled <- ComputeTemporalLRWithIntermediate(
    f$x, f$ct, f$lr_db, f$pt, f$lw,
    n_bins = 4L, min_pct = 0, min_n_eff = 0.1
  )
  expect_equal(
    LineaLinkR:::.compute_lineage_bin_bounds(f$pt, f$lw, 4L),
    attr(pooled$scores, "bin_bounds"),
    tolerance = 1e-7
  )
})

test_that("sample subsets retain pooled boundaries", {
  f <- make_temporal_fixture()
  pooled <- ComputeTemporalLRWithIntermediate(
    f$x, f$ct, f$lr_db, f$pt, f$lw,
    n_bins = 4L, min_pct = 0, min_n_eff = 0.1,
    return_complete_grid = TRUE
  )
  bounds <- attr(pooled$scores, "bin_bounds")
  donor_a <- c(seq_len(10L), 31:40)
  donor_b <- 11:30
  a <- ComputeTemporalLRFixedBounds(
    f$x[, donor_a], f$ct[donor_a], f$lr_db,
    f$pt[donor_a], f$lw[donor_a, , drop = FALSE],
    bounds, attr(pooled$scores, "hill_scale"),
    n_bins = 4L, min_pct = 0, min_n_eff = 0.1
  )
  b <- ComputeTemporalLRFixedBounds(
    f$x[, donor_b], f$ct[donor_b], f$lr_db,
    f$pt[donor_b], f$lw[donor_b, , drop = FALSE],
    bounds, attr(pooled$scores, "hill_scale"),
    n_bins = 4L, min_pct = 0, min_n_eff = 0.1
  )
  local_a <- LineaLinkR:::.compute_lineage_bin_bounds(
    f$pt[donor_a], f$lw[donor_a, , drop = FALSE], 4L
  )
  local_b <- LineaLinkR:::.compute_lineage_bin_bounds(
    f$pt[donor_b], f$lw[donor_b, , drop = FALSE], 4L
  )
  expect_false(identical(local_a, local_b))
  expect_equal(attr(a, "bin_bounds"), bounds)
  expect_equal(attr(b, "bin_bounds"), bounds)
  expect_equal(
    LineaLinkR:::.lineage_cell_bin_index(
      0.25, attr(a, "bin_bounds")[[1L]], 4L
    ),
    LineaLinkR:::.lineage_cell_bin_index(
      0.25, attr(b, "bin_bounds")[[1L]], 4L
    )
  )
})

test_that("sample support exposes a single-donor positive contrast", {
  x <- data.frame(
    pair_idx = rep(1:2, each = 4),
    source = 1L,
    target = 2L,
    lineage = 1L,
    block_label = rep(paste0("D", 1:4), 2),
    sibling_contrast = c(1.0, 0.8, 1.1, 0.9, 5.0, -0.2, -0.3, -0.1),
    evaluable = TRUE
  )
  out <- SummarizeForkContrastsBySample(x, n_boot = 200L, seed = 12345L)
  expect_gt(out$sample_support[out$pair_idx == 1L], 0.9)
  expect_equal(out$sample_support[out$pair_idx == 2L], 0.75)
  expect_lt(out$positive_sample_fraction[out$pair_idx == 2L], 0.5)
  expect_gt(out$median_contrast[out$pair_idx == 1L], 0)
  expect_lt(out$median_contrast[out$pair_idx == 2L], 0)
})

test_that("sample support accepts data.table input from the production runner", {
  x <- data.table::data.table(
    pair_idx = rep(1:2, each = 4),
    source = 1L,
    target = 2L,
    lineage = 1L,
    block_label = rep(paste0("D", 1:4), 2),
    sibling_contrast = c(1.0, 0.8, 1.1, 0.9, 5.0, -0.2, -0.3, -0.1),
    evaluable = TRUE
  )
  out <- SummarizeForkContrastsBySample(x, n_boot = 200L, seed = 12345L)
  expect_s3_class(out, "data.frame")
  expect_equal(out$sample_support[out$pair_idx == 1L], 1)
  expect_equal(out$sample_support[out$pair_idx == 2L], 0.75)
})

test_that("single-sample contrast is descriptive only", {
  x <- data.frame(
    pair_idx = 1L,
    source = 1L,
    target = 2L,
    lineage = 1L,
    block_label = "D1",
    sibling_contrast = 0.7,
    evaluable = TRUE
  )
  out <- SummarizeForkContrastsBySample(x, n_boot = 200L, seed = 12345L)
  expect_equal(out$inference_unit, "single_sample_descriptive")
  expect_true(is.na(out$ci_low) && is.na(out$ci_high))
  expect_false("p_value" %in% colnames(out))
})

test_that("evidence composition preserves missing support layers", {
  fork <- data.frame(
    pair_idx = 1:2,
    source = 1L,
    target = 2L,
    lineage = 1L,
    activity_strength = c(2, 1),
    pre_fork_enrichment = c(0.2, 0.7),
    fork_locality = c(0.5, 0.1),
    post_fork_change = c(1, -0.2),
    sibling_contrast = c(0.8, -0.1),
    post_fork_persistence = c(0.9, 0.4),
    evaluable = TRUE
  )
  response <- data.frame(
    pair_idx = 1L,
    source = 1L,
    target = 2L,
    lineage = 1L,
    receiver_response_support = 0.75
  )
  out <- ComposeForkEvidence(fork, response_support = response)
  expect_equal(out$evidence_completeness, c("fork+response", "fork_only"))
  expect_true(is.na(out$receiver_response_support[2L]))
  expect_false(any(grepl(
    "instructive|reinforcing|feedback|lateral",
    colnames(out), ignore.case = TRUE
  )))
})

test_that("evidence composition preserves pooled and sample inference units", {
  fork <- data.frame(
    pair_idx = 1L,
    source = 1L,
    target = 2L,
    lineage = 1L,
    activity_strength = 2,
    pre_fork_enrichment = 0.2,
    fork_locality = 0.5,
    post_fork_change = 1,
    sibling_contrast = 0.8,
    post_fork_persistence = 0.9,
    evaluable = TRUE,
    inference_unit = "pooled_cells_descriptive"
  )
  sample <- data.frame(
    pair_idx = 1L,
    source = 1L,
    target = 2L,
    lineage = 1L,
    sample_support = 0.8,
    inference_unit = "biological_sample_bootstrap"
  )
  out <- ComposeForkEvidence(fork, sample_support = sample)
  expect_equal(out$inference_unit, "pooled_cells_descriptive")
  expect_equal(out$sample_inference_unit, "biological_sample_bootstrap")
  expect_equal(out$evidence_completeness, "fork+sample")
})
