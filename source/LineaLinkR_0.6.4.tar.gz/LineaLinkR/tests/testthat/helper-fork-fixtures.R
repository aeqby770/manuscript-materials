make_fork_score_fixture <- function() {
  grid <- expand.grid(
    pair_idx = 1:3,
    source = 1L,
    target = 2L,
    lineage = 1:2,
    bin = 1:6,
    KEEP.OUT.ATTRS = FALSE,
    stringsAsFactors = FALSE
  )
  shared <- c(1, 1, 1, 3, 4, 5)
  focal <- c(1, 1, 1, 5, 6, 7)
  flat <- rep(0.05, 6)
  profiles <- list(
    `1.1` = shared,
    `1.2` = shared,
    `2.1` = focal,
    `2.2` = shared,
    `3.1` = flat,
    `3.2` = flat
  )
  key <- paste(grid$pair_idx, grid$lineage, sep = ".")
  grid$score <- unlist(
    Map(function(k, b) profiles[[k]][b], key, grid$bin),
    use.names = FALSE
  )
  grid$n_eff_cells <- 20
  grid$structurally_valid <- TRUE
  list(
    scores = grid,
    bif = data.frame(
      lineage = 1:2,
      b_star = c(3L, 3L),
      reason = "crossing"
    ),
    sibling = data.frame(
      focal_lineage = c(1L, 2L),
      sibling_lineage = c(2L, 1L),
      fork_cluster = 1L,
      shared_prefix_length = 1L
    )
  )
}
