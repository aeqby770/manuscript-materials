# LineaLinkR

Rust core with an R wrapper (extendr) for trajectory-linked ligand–receptor
cell–cell communication analysis. Extracted from the Seurat-RS codebase.

## Modules

| Rust module | Role |
|-------------|------|
| `src/trajectory/pseudotime.rs` | Fuzzy Dijkstra pseudotime, lineage extraction, soft weights, fate probabilities, trajectory DE |
| `src/ccc/lr_scoring.rs` | Cluster-level and pseudotime-binned LR scores |
| `src/ccc/taxonomy.rs` | Lineage entropy curves, bifurcation detection, role scoring |
| `src/ccc/fake_lr.rs` | Stratified fake-LR null model |
| `src/ccc/evidence.rs` | Aligned profile-correlation evidence decomposition |
| `src/ccc/temporal_null.rs` | Within-cell-type/lineage temporal permutation null |

Public R entry points: `R/linealinkr.R`, `R/start_cell.R`, `R/graph_knn.R`.

# Installation

The source package contains the current statistical implementation.
Install the generated source archive with R, Rust, Rtools, **Matrix**, and **RANN**
available; see **[INSTALL.md](INSTALL.md)**.

```r
install.packages(c("Matrix", "RANN"))
install.packages("path/to/LineaLinkR_0.6.4.tar.gz",
                 repos = NULL, type = "source")
library(LineaLinkR)
```

Requires R ≥ 4.2, Rust ≥ 1.65, GNU `make`, and **Matrix**. See
**[INSTALL.md](INSTALL.md)** and **[BUILD_NOTES.md](BUILD_NOTES.md)**.

```bash
R CMD INSTALL .
```

## Quick start (synthetic data)

```r
library(Matrix)
library(LineaLinkR)

set.seed(1)
n <- 40L; k <- 5L
emb <- cbind(seq(0, 1, length.out = n), rnorm(n, sd = 0.05))
cl <- rep(1:4, each = 10L)
nn_idx <- matrix(0L, n, k); nn_dists <- matrix(0, n, k)
for (i in seq_len(n)) {
  d <- sqrt(rowSums((emb - matrix(emb[i, ], n, 2, byrow = TRUE))^2))
  o <- order(d)[2:(k + 1L)]
  nn_idx[i, ] <- o; nn_dists[i, ] <- d[o]
}
root <- InferStartCellAuto(emb, cl, nn_idx, nn_dists, seed = 1L)
root$root_direction_status
pt <- ComputePseudotimeFuzzy(nn_idx, nn_dists, root$start_cell)
w <- ComputeLineageWeightsTrunkAware(emb, cl, cl[[root$start_cell]], sigma = 0.3)
expr <- abs(Matrix::rsparsematrix(20, n, density = 0.25))
lr_db <- list(ligand_rows = list(c(1L)), receptor_rows = list(c(2L)))
ComputeTemporalLR(expr, cl, lr_db, pt, w, n_bins = 5L, min_pct = 0.05)
```

`ComputeTemporalLR()` returns a complete lineage-by-bin grid for each
prescreened LR/source/target context. Structural-invalid bins have `score = NA`;
structurally valid bins below the expression gate have `score = 0`. Use the same
`min_n_eff` value in temporal scoring, FakeLR, and temporal permutation.

## Scope and limitations

LineaLinkR is a **trajectory-aware CCC framework**, not a general pseudotime
SOTA tool. Blind root selection is a heuristic without ground truth; reversed
pseudotime direction is an expected limitation when no biological root prior
is available. `InferStartCellAuto()` reports PC-sign ambiguity when opposite
candidate roots have indistinguishable ordering quality. Evidence decomposition reports aligned source/target
profile-correlation within each stratum — not partial correlation or a formal
conditional-independence test. Formal dynamic support is reported at the
trajectory level by `ComputeTemporalPermutation()`; bin-level values are
max-statistic localisation results rather than independent discovery tests.
The permutation null evaluates temporal structure conditional on the supplied
pseudotime and does not validate root direction. Publication FakeLR inference
uses `ComputeTrajectoryFakeLRNull()`, with matched-caliper sampling, a shared
real/fake Hill scale, coverage auditing, and trajectory-level BH correction.

## Further reading

- [INSTALL-BINARY.md](INSTALL-BINARY.md) — status of platform-specific binaries
- [INSTALL.md](INSTALL.md) — source install (developers)
- [BUILD_NOTES.md](BUILD_NOTES.md) — toolchain matrix and Windows troubleshooting
