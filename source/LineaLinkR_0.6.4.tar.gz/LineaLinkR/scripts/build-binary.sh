#!/usr/bin/env bash
# Build a platform binary package (Linux/macOS). Reviewers install without Rust.
# Usage:  bash scripts/build-binary.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
mkdir -p dist
rm -f dist/LineaLinkR_*.tar.gz LineaLinkR_*.tar.gz

echo "==> Building binary package"
R CMD INSTALL --build .

mv LineaLinkR_*.tar.gz dist/
ARTIFACT="$(ls -1 dist/LineaLinkR_*.tar.gz | head -1)"
VER="$(sed -n 's/^Version: //p' DESCRIPTION | head -1)"
{
  echo "# LineaLinkR binary build metadata"
  echo
  echo "| Field | Value |"
  echo "|-------|-------|"
  echo "| Package version | ${VER} |"
  echo "| Build date | $(date -u +%Y-%m-%d) |"
  echo "| R | $(R --version | head -1) |"
  echo "| Platform | $(R CMD config --arch)-$(R CMD config --platform) |"
  echo "| Artifact | $(basename "$ARTIFACT") |"
  echo "| SHA256 | $(sha256sum "$ARTIFACT" | awk '{print $1}') |"
} > dist/BUILD_INFO.md

echo "==> Wrote ${ARTIFACT}"
