# Build a Windows win.binary package (no Rust needed at install time).
# Run from the package root:  pwsh scripts/build-binary.ps1
param(
    [string]$RHome = $env:R_HOME
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

if (-not $RHome) {
    $RHome = "D:\R\R-4.5.3"
}
$Rexe = Join-Path $RHome "bin\x64\R.exe"
if (-not (Test-Path $Rexe)) {
    throw "R not found at $Rexe. Set -RHome or R_HOME."
}

New-Item -ItemType Directory -Force -Path dist | Out-Null
Remove-Item dist\LineaLinkR_*.zip -ErrorAction SilentlyContinue
Remove-Item LineaLinkR_*.zip -ErrorAction SilentlyContinue

Write-Host "==> Building win.binary with $Rexe"
& $Rexe CMD INSTALL --build .

$zip = Get-ChildItem -Path $Root -Filter "LineaLinkR_*.zip" | Select-Object -First 1
if (-not $zip) { throw "R CMD INSTALL --build did not produce a .zip" }

Move-Item -Force $zip.FullName dist\
$artifact = Get-ChildItem dist\LineaLinkR_*.zip | Select-Object -First 1

$hash = Get-FileHash $artifact.FullName -Algorithm SHA256
$rv = & $Rexe --version 2>&1 | Select-Object -First 1

@"
# LineaLinkR binary build metadata

| Field | Value |
|-------|-------|
| Package version | $( (Select-Xml -Path DESCRIPTION -XPath '/Package/Version').Node.InnerText ) |
| Build date | $(Get-Date -Format 'yyyy-MM-dd') |
| R | $rv |
| Platform | $env:PROCESSOR_ARCHITECTURE (Windows) |
| Artifact | $($artifact.Name) |
| Size bytes | $($artifact.Length) |
| SHA256 | $($hash.Hash) |
"@ | Set-Content -Encoding UTF8 dist\BUILD_INFO.md

Write-Host "==> Wrote dist\$($artifact.Name) ($([math]::Round($artifact.Length/1MB, 2)) MB)"
Write-Host "==> SHA256 $($hash.Hash)"
